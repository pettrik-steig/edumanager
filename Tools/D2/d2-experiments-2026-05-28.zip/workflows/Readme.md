project: EduManager 2026
created: 2026-05-28 (Data)
changed: 2026-05-28 (Data)

# Workflow Development

This directory contains application-side workflow concepts for EduManager.

The focus is on work that a teacher or other user wants to perform with the
application. These documents should stay close to practical usage before the
ideas are translated into architecture, domain objects, or implementation
tasks.

Files:

- [workflow-overview.md](workflow-overview.md): school-year rhythm and first
  situation map
- [student-joins-lerngruppe.d2](student-joins-lerngruppe.d2): first bottom-up
  workflow sketch for a student joining an existing learning group
- [student-joins-official-info.d2](student-joins-official-info.d2): official
  information transfer for a student joining a learning group
- [student-joins-student-checkback.d2](student-joins-student-checkback.d2):
  student checkback after app data is used in class
- [student-joins-lerngruppe.md](student-joins-lerngruppe.md): notes for the
  information-transfer focus of that situation
- [lesson-room-change.md](lesson-room-change.md): first concrete work
  situation
- [workflow-overview.d2](workflow-overview.d2): visual overview of the
  school-year rhythm and situation groups
- [workflow-overview.svg](workflow-overview.svg): rendered SVG preview

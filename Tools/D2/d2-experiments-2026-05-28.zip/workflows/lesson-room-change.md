project: EduManager 2026
created: 2026-05-28 (Data)
changed: 2026-05-28 (Data)

# Lesson Room Change

## Situation

A teacher wants to prepare a concrete lesson, but the planned or usual room is
not available, has changed, or has a different usable setup than expected.

The task is not "manage rooms" or "edit seating plans" in the abstract. The
task is to become ready for this concrete lesson without losing track of the
learning group, room constraints, and usable seating arrangement.

## Anlass

The work starts because a concrete teaching situation needs attention.

Possible triggers:

- the timetable assigns a different room than usual
- the room was changed shortly before the lesson
- the room setup is incomplete, blocked, or different from the stored default
- the teacher wants to check whether an existing seating arrangement still
  works

The teacher's immediate question:

```text
Can I use a suitable seating arrangement for this lesson in this concrete room
situation?
```

## Bearbeitung

The teacher clarifies the situation step by step.

Likely handling:

- identify the learning group
- identify the concrete lesson or time slot
- identify the assigned or available room
- compare the expected room setup with the actual room situation
- select an existing seating arrangement if it still fits
- adapt or create a seating arrangement if needed
- mark uncertainties or temporary assumptions when the situation is not fully
  known

The work should allow quick decisions without forcing the user to fully model
the whole school first.

## Ergebnis

The useful result is practical readiness for the lesson.

Possible outputs:

- a selected seating arrangement for the concrete room situation
- a temporarily adapted seating arrangement
- a note that no suitable arrangement exists yet
- a visible list of unresolved constraints or assumptions
- an updated room situation if the change should be reused later

The result should help the teacher continue directly into lesson preparation or
classroom use.

## Information Needed

- learning group
- student list or relevant subset of students
- timetable or lesson context
- room
- concrete room situation
- existing seating arrangements
- known constraints

## Design Notes

This situation suggests that EduManager should distinguish between:

- a room as a general place
- a room situation as the concrete usable setup for a teaching context
- a seating arrangement as something that may depend on a room situation

It also suggests that the app should support incomplete information. A teacher
may need a useful working state before all data is perfectly modeled.

project: EduManager 2026
created: 2026-05-28 (Data)
changed: 2026-05-28 (Data)

# Student Joins Existing Lerngruppe

## Purpose

This document collects early notes for the situation where a student joins an
existing `Lerngruppe`.

The current focus is information transfer, not UI design or full process
sequence.

## Current Analysis Focus

The situation is split into two separate information-transfer diagrams:

- official information is processed
- the teacher checks back with the student after app data has produced a
  seating-plan/classroom-use artifact

At this level, data stores and transferred data are distinguished by their
medium:

- human: memory or spoken information
- mechanical: paper
- electronic: computer or e-mail

The same medium category can mean different things depending on whether it is
a data store or transferred data.

Electronic data will later need a more precise distinction regarding
persistence. That distinction is intentionally not modeled yet.

## Diagram

- [student-joins-lerngruppe.d2](student-joins-lerngruppe.d2): relationship
  between the two sub-processes
- [student-joins-official-info.d2](student-joins-official-info.d2): official
  information is processed
- [student-joins-student-checkback.d2](student-joins-student-checkback.d2):
  checkback with the student

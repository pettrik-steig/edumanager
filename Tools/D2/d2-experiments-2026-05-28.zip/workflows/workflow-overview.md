project: EduManager 2026
created: 2026-05-28 (Data)
changed: 2026-05-28 (Data)

# Workflow Overview

## Purpose

This document starts the usage-side view of EduManager.

The first goal is not to design app modules. The first goal is to identify
concrete school work situations and place them in their time relationship.

Detailed descriptions of individual situations come later.

## Working Principle

Workflow work starts from real situations, not from planned app modules.

First step:

- name relevant work situations
- place them in the school-year rhythm
- understand which situations are regular, occasional, or urgent

Second step:

- describe each situation in detail
- use `Anlass`, `Bearbeitung`, and `Ergebnis`
- derive candidate features, data structures, and architecture questions only
  after the situation is understood

## School-Year Rhythm

The school-year change is the central rhythm-setting situation.

It creates the largest amount of work because many structures need to be
created, copied, revised, checked, or reopened for a new year. During the
school year, the work is usually smaller and more event-driven.

The basic rhythm is a loop:

```text
school-year change -> work during the school year -> next school-year change
```

In domain terms, the first map should be read as a German school-year flow:

```text
Schuljahreswechsel
-> 1. Halbjahr
-> Halbjahreswechsel
-> 2. Halbjahr
-> Schuljahreswechsel
```

Here, `Anlass` is interpreted as a temporal phase or work occasion that can
initiate actions. It is not necessarily a single point in time.

During both semesters, repeated events can occur without a fixed order. Some
events are part of the yearly rhythm, while others are triggered by changed
school data or daily teaching situations.

The visual map distinguishes:

- `Anlass`: a reason or event that starts work
- `Aktion`: work that the user performs
- solid blue edges: temporal order
- dashed gray edges: implication or initiation

## First Situation Map

### Year Boundary

- school-year change
- prepare new project state
- carry over useful information from the previous year
- decide what must be reset, copied, adapted, or archived

### During The School Year

- semester change
- new timetable
- changed course assignment
- new student
- student leaves
- room change
- changed room situation
- seating arrangement adjustment
- temporary lesson or substitution situation

## Open Questions

- Which situations belong to the regular yearly rhythm?
- Which situations happen only when external school data changes?
- Which situations must be handled quickly during daily school work?
- Which information can be copied from the previous school year?
- Which information must intentionally not be copied?
- Which situations should be detailed first after the map is stable?
